module {
  func.func @inference_to_compile(%arg0: tensor<1x3x!FHE.esint<8>>) -> tensor<1x1x!FHE.eint<8>> {
    %cst = arith.constant dense<[[0], [3], [-4]]> : tensor<3x1xi4>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x3x!FHE.esint<8>>, tensor<3x1xi4>) -> tensor<1x1x!FHE.esint<8>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x3x!FHE.esint<8>>) -> tensor<1x1x!FHE.esint<8>>
    %c9_i5 = arith.constant 9 : i5
    %from_elements = tensor.from_elements %c9_i5 : tensor<1xi5>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<1x1x!FHE.esint<8>>, tensor<1xi5>) -> tensor<1x1x!FHE.esint<8>>
    %3 = "FHELinalg.sub_eint"(%0, %2) : (tensor<1x1x!FHE.esint<8>>, tensor<1x1x!FHE.esint<8>>) -> tensor<1x1x!FHE.esint<8>>
    %cst_0 = arith.constant dense<42> : tensor<1x1xi7>
    %4 = "FHELinalg.to_unsigned"(%3) : (tensor<1x1x!FHE.esint<8>>) -> tensor<1x1x!FHE.eint<8>>
    %5 = "FHELinalg.add_eint_int"(%4, %cst_0) : (tensor<1x1x!FHE.eint<8>>, tensor<1x1xi7>) -> tensor<1x1x!FHE.eint<8>>
    return %5 : tensor<1x1x!FHE.eint<8>>
  }
}