module {
  func.func @inference_to_compile(%arg0: tensor<1x5x!FHE.esint<6>>) -> tensor<1x3x!FHE.esint<6>> {
    %cst = arith.constant dense<[[-2, 0, 1], [-3, -1, 3], [-4, 2, 2], [-1, 0, 1], [3, -1, -2]]> : tensor<5x3xi4>
    %0 = "FHELinalg.matmul_eint_int"(%arg0, %cst) : (tensor<1x5x!FHE.esint<6>>, tensor<5x3xi4>) -> tensor<1x3x!FHE.esint<6>>
    %1 = "FHELinalg.sum"(%arg0) {axes = [1], keep_dims = true} : (tensor<1x5x!FHE.esint<6>>) -> tensor<1x1x!FHE.esint<6>>
    %c0_i2 = arith.constant 0 : i2
    %from_elements = tensor.from_elements %c0_i2 : tensor<1xi2>
    %2 = "FHELinalg.to_unsigned"(%1) : (tensor<1x1x!FHE.esint<6>>) -> tensor<1x1x!FHE.eint<6>>
    %3 = "FHELinalg.mul_eint_int"(%2, %from_elements) : (tensor<1x1x!FHE.eint<6>>, tensor<1xi2>) -> tensor<1x1x!FHE.eint<6>>
    %4 = "FHELinalg.to_signed"(%3) : (tensor<1x1x!FHE.eint<6>>) -> tensor<1x1x!FHE.esint<6>>
    %5 = "FHELinalg.sub_eint"(%0, %4) : (tensor<1x3x!FHE.esint<6>>, tensor<1x1x!FHE.esint<6>>) -> tensor<1x3x!FHE.esint<6>>
    %cst_0 = arith.constant dense<[[4, 3, -5]]> : tensor<1x3xi5>
    %6 = "FHELinalg.add_eint_int"(%5, %cst_0) : (tensor<1x3x!FHE.esint<6>>, tensor<1x3xi5>) -> tensor<1x3x!FHE.esint<6>>
    return %6 : tensor<1x3x!FHE.esint<6>>
  }
}