module {
  func.func @_lambda__proxy(%arg0: tensor<1x4x!FHE.eint<3>>) -> tensor<1x1x2x!FHE.esint<3>> {
    %0 = "FHELinalg.transpose"(%arg0) {axes = []} : (tensor<1x4x!FHE.eint<3>>) -> tensor<4x1x!FHE.eint<3>>
    %cst = arith.constant dense<[[0, 0, 0, 1], [0, 1, 0, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 1, 0], [0, 0, 0, 1]]> : tensor<6x4xi2>
    %1 = "FHELinalg.matmul_int_eint"(%cst, %0) : (tensor<6x4xi2>, tensor<4x1x!FHE.eint<3>>) -> tensor<6x1x!FHE.eint<3>>
    %c1_i2 = arith.constant 1 : i2
    %from_elements = tensor.from_elements %c1_i2 : tensor<1xi2>
    %2 = "FHELinalg.mul_eint_int"(%1, %from_elements) : (tensor<6x1x!FHE.eint<3>>, tensor<1xi2>) -> tensor<6x1x!FHE.eint<3>>
    %c0_i2 = arith.constant 0 : i2
    %from_elements_0 = tensor.from_elements %c0_i2 : tensor<1xi2>
    %3 = "FHELinalg.add_eint_int"(%2, %from_elements_0) : (tensor<6x1x!FHE.eint<3>>, tensor<1xi2>) -> tensor<6x1x!FHE.eint<3>>
    %cst_1 = arith.constant dense<[[5], [2], [4], [5], [3], [5]]> : tensor<6x1xi4>
    %cst_2 = arith.constant dense<[[0], [1], [2], [0], [3], [0]]> : tensor<6x1xindex>
    %cst_3 = arith.constant dense<[[1, 1, 1, 1, 1, 0, 0, 0], [1, 1, 0, 0, 0, 0, 0, 0], [1, 1, 1, 1, 0, 0, 0, 0], [1, 1, 1, 0, 0, 0, 0, 0]]> : tensor<4x8xi64>
    %4 = "FHELinalg.apply_mapped_lookup_table"(%3, %cst_3, %cst_2) : (tensor<6x1x!FHE.eint<3>>, tensor<4x8xi64>, tensor<6x1xindex>) -> tensor<6x1x!FHE.eint<3>>
    %expanded = tensor.expand_shape %4 [[0, 1], [2]] : tensor<6x1x!FHE.eint<3>> into tensor<2x3x1x!FHE.eint<3>>
    %cst_4 = arith.constant dense<[[[1, 1, 0], [1, -1, 0], [-1, 0, 1], [-1, 0, -1]], [[1, 1, 0], [1, -1, 0], [-1, 0, 1], [-1, 0, -1]]]> : tensor<2x4x3xi3>
    %5 = "FHELinalg.to_signed"(%expanded) : (tensor<2x3x1x!FHE.eint<3>>) -> tensor<2x3x1x!FHE.esint<3>>
    %6 = "FHELinalg.matmul_int_eint"(%cst_4, %5) : (tensor<2x4x3xi3>, tensor<2x3x1x!FHE.esint<3>>) -> tensor<2x4x1x!FHE.esint<3>>
    %collapsed = tensor.collapse_shape %6 [[0, 1], [2]] : tensor<2x4x1x!FHE.esint<3>> into tensor<8x1x!FHE.esint<3>>
    %cst_5 = arith.constant dense<[[2], [1], [1], [0], [2], [1], [1], [0]]> : tensor<8x1xi3>
    %cst_6 = arith.constant dense<[[0], [1], [1], [2], [0], [1], [1], [2]]> : tensor<8x1xindex>
    %cst_7 = arith.constant dense<[[0, 0, 1, 0, 0, 0, 0, 0], [0, 1, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0]]> : tensor<3x8xi64>
    %7 = "FHELinalg.apply_mapped_lookup_table"(%collapsed, %cst_7, %cst_6) : (tensor<8x1x!FHE.esint<3>>, tensor<3x8xi64>, tensor<8x1xindex>) -> tensor<8x1x!FHE.eint<3>>
    %expanded_8 = tensor.expand_shape %7 [[0, 1], [2]] : tensor<8x1x!FHE.eint<3>> into tensor<2x4x1x!FHE.eint<3>>
    %cst_9 = arith.constant dense<[[[-2, -1, -1, -3]], [[0, -2, 0, -2]]]> : tensor<2x1x4xi4>
    %8 = "FHELinalg.to_signed"(%expanded_8) : (tensor<2x4x1x!FHE.eint<3>>) -> tensor<2x4x1x!FHE.esint<3>>
    %9 = "FHELinalg.matmul_int_eint"(%cst_9, %8) : (tensor<2x1x4xi4>, tensor<2x4x1x!FHE.esint<3>>) -> tensor<2x1x1x!FHE.esint<3>>
    %collapsed_10 = tensor.collapse_shape %9 [[0], [1, 2]] : tensor<2x1x1x!FHE.esint<3>> into tensor<2x1x!FHE.esint<3>>
    %10 = "FHELinalg.transpose"(%collapsed_10) {axes = [1, 0]} : (tensor<2x1x!FHE.esint<3>>) -> tensor<1x2x!FHE.esint<3>>
    %expanded_11 = tensor.expand_shape %10 [[0], [1, 2]] : tensor<1x2x!FHE.esint<3>> into tensor<1x1x2x!FHE.esint<3>>
    return %expanded_11 : tensor<1x1x2x!FHE.esint<3>>
  }
}